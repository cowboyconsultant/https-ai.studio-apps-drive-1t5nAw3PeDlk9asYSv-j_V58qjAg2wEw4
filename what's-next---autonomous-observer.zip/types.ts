
export type LogCategory = 'activity' | 'thought' | 'location' | 'download' | 'media';

export interface LifeLog {
  id: string;
  timestamp: number;
  category: LogCategory;
  content: string;
  metadata?: Record<string, any>;
}

export interface Prediction {
  type: string;
  likelihood: number;
  description: string;
  suggestion: string;
}

export interface AnalysisResult {
  currentPatterns: string[];
  predictions: Prediction[];
  summary: string;
}
