
import React from 'react';
import { LifeLog } from '../types';

interface LogListProps {
  logs: LifeLog[];
}

const categoryIcons: Record<string, string> = {
  activity: 'fa-bolt',
  thought: 'fa-brain',
  location: 'fa-map-marker-alt',
  download: 'fa-download',
  media: 'fa-film'
};

const LogList: React.FC<LogListProps> = ({ logs }) => {
  return (
    <div className="flex flex-col gap-3 h-[400px] overflow-y-auto pr-2">
      {logs.length === 0 ? (
        <div className="text-gray-500 italic text-center py-10">
          No logs captured yet. Start typing or record data.
        </div>
      ) : (
        logs.map((log) => (
          <div key={log.id} className="p-3 glass rounded-xl flex gap-4 border border-white/5 items-start">
            <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400">
              <i className={`fas ${categoryIcons[log.category] || 'fa-stream'}`}></i>
            </div>
            <div className="flex-1">
              <div className="flex justify-between items-center mb-1">
                <span className="text-xs font-semibold uppercase tracking-wider text-gray-400">
                  {log.category}
                </span>
                <span className="text-[10px] text-gray-500">
                  {new Date(log.timestamp).toLocaleTimeString()}
                </span>
              </div>
              <p className="text-sm text-gray-200">{log.content}</p>
            </div>
          </div>
        ))
      )}
    </div>
  );
};

export default LogList;
