
import React from 'react';
import { AnalysisResult } from '../types';

interface InsightsPanelProps {
  analysis: AnalysisResult | null;
  isLoading: boolean;
}

const InsightsPanel: React.FC<InsightsPanelProps> = ({ analysis, isLoading }) => {
  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center h-full space-y-4 py-20">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
        <p className="text-blue-400 font-medium animate-pulse">Running Predictive Models...</p>
      </div>
    );
  }

  if (!analysis) {
    return (
      <div className="h-full flex items-center justify-center text-gray-500 italic">
        Gather more data to unlock predictive insights.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <section>
        <h3 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
          <i className="fas fa-microchip text-blue-500"></i>
          Analysis Summary
        </h3>
        <p className="text-gray-300 text-sm leading-relaxed glass p-4 rounded-xl border-l-4 border-l-blue-500">
          {analysis.summary}
        </p>
      </section>

      <section>
        <h3 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
          <i className="fas fa-chart-line text-green-500"></i>
          Detected Patterns
        </h3>
        <div className="flex flex-wrap gap-2">
          {analysis.currentPatterns.map((pattern, i) => (
            <span key={i} className="px-3 py-1 bg-green-500/10 text-green-400 text-xs rounded-full border border-green-500/20">
              {pattern}
            </span>
          ))}
        </div>
      </section>

      <section>
        <h3 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
          <i className="fas fa-forward text-purple-500"></i>
          What's Next? (Predictions)
        </h3>
        <div className="space-y-3">
          {analysis.predictions.map((p, i) => (
            <div key={i} className="glass p-4 rounded-xl border border-white/5 hover:border-blue-500/30 transition-all">
              <div className="flex justify-between items-start mb-2">
                <span className="text-xs font-bold text-purple-400 uppercase">{p.type}</span>
                <span className="text-[10px] bg-gray-800 px-2 py-0.5 rounded text-gray-300">
                  {Math.round(p.likelihood * 100)}% Confidence
                </span>
              </div>
              <p className="text-sm font-semibold text-gray-100 mb-1">{p.description}</p>
              <p className="text-xs text-gray-400 italic">Suggestion: {p.suggestion}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default InsightsPanel;
