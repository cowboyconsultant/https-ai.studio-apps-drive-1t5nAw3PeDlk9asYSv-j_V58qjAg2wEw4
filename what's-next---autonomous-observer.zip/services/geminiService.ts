
import { GoogleGenAI, Type } from "@google/genai";
import { LifeLog, AnalysisResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const analyzeLifeLogs = async (logs: LifeLog[]): Promise<AnalysisResult> => {
  const model = 'gemini-3-flash-preview';
  
  const logData = logs.map(l => ({
    time: new Date(l.timestamp).toISOString(),
    cat: l.category,
    val: l.content
  }));

  const prompt = `Analyze the following stream of personal activity data. 
  Identify recurring patterns, routines, and habits. Based on these observed patterns, 
  generate realistic "possibilities" for what the user might encounter or do next. 
  
  Focus on helpful, grounded pattern recognition such as schedule optimization, 
  social tendencies, or productivity cycles. 
  
  Data Stream: ${JSON.stringify(logData)}
  
  Return the analysis as a JSON object.`;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            currentPatterns: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Current habits or routines identified."
            },
            predictions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  type: { type: Type.STRING, description: "Category of prediction (e.g., Work, Wellness, Social)" },
                  likelihood: { type: Type.NUMBER, description: "0 to 1 value" },
                  description: { type: Type.STRING, description: "What might happen next based on data" },
                  suggestion: { type: Type.STRING, description: "Advice for the user" }
                },
                required: ["type", "likelihood", "description", "suggestion"]
              }
            },
            summary: {
              type: Type.STRING,
              description: "Overall narrative summary of the analysis."
            }
          },
          required: ["currentPatterns", "predictions", "summary"]
        }
      }
    });

    const text = response.text || "{}";
    return JSON.parse(text) as AnalysisResult;
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    return {
      currentPatterns: ["Unable to analyze patterns at this time."],
      predictions: [],
      summary: "There was an error processing your data stream. Please try again later."
    };
  }
};
