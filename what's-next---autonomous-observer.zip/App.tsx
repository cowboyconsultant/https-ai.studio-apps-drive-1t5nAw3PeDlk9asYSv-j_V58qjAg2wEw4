
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { LifeLog, AnalysisResult, LogCategory } from './types';
import LogList from './components/LogList';
import InsightsPanel from './components/InsightsPanel';
import { analyzeLifeLogs } from './services/geminiService';

const App: React.FC = () => {
  const [logs, setLogs] = useState<LifeLog[]>([]);
  const [inputText, setInputText] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<LogCategory>('activity');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [isObserverMode, setIsObserverMode] = useState(false);
  const [locationStatus, setLocationStatus] = useState<'idle' | 'tracking' | 'error'>('idle');
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [showInstallGuide, setShowInstallGuide] = useState(false);
  
  const logsRef = useRef<LifeLog[]>([]);
  useEffect(() => { logsRef.current = logs; }, [logs]);

  // Handle PWA Installation
  useEffect(() => {
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
    });

    window.addEventListener('appinstalled', () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    });

    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstalled(true);
    }
  }, []);

  const handleInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') setDeferredPrompt(null);
    } else {
      setShowInstallGuide(true);
    }
  };

  const shareApp = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: "What's Next",
          text: "Check out this autonomous life observer and prediction engine!",
          url: window.location.href,
        });
      } catch (err) {
        console.log("Share failed:", err);
      }
    } else {
      // Fallback: Copy to clipboard
      navigator.clipboard.writeText(window.location.href);
      alert("App link copied to clipboard! Share it on Facebook or with friends.");
    }
  };

  const exportData = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(logs, null, 2));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", "whats_next_data.json");
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  };

  // Persistence
  useEffect(() => {
    const savedLogs = localStorage.getItem('whats_next_logs');
    if (savedLogs) setLogs(JSON.parse(savedLogs));
  }, []);

  useEffect(() => {
    localStorage.setItem('whats_next_logs', JSON.stringify(logs));
  }, [logs]);

  const addLog = useCallback((content: string, category: LogCategory) => {
    if (!content.trim()) return;
    const newLog: LifeLog = {
      id: Math.random().toString(36).substr(2, 9),
      timestamp: Date.now(),
      category,
      content
    };
    setLogs(prev => [newLog, ...prev]);
  }, []);

  // --- AUTONOMOUS OBSERVER LOGIC ---
  useEffect(() => {
    if (!isObserverMode) {
      setLocationStatus('idle');
      return;
    }

    let watchId: number;
    if ("geolocation" in navigator) {
      setLocationStatus('tracking');
      watchId = navigator.geolocation.watchPosition(
        (pos) => {
          const { latitude, longitude } = pos.coords;
          const lastLog = logsRef.current.find(l => l.category === 'location');
          if (!lastLog || Date.now() - lastLog.timestamp > 60000) {
            addLog(`Location check-in: ${latitude.toFixed(3)}N, ${longitude.toFixed(3)}E`, 'location');
          }
        },
        () => setLocationStatus('error'),
        { enableHighAccuracy: true }
      );
    }
    return () => navigator.geolocation.clearWatch(watchId);
  }, [isObserverMode, addLog]);

  useEffect(() => {
    if (!isObserverMode) return;
    const handleVisibility = () => {
      const state = document.visibilityState;
      addLog(`Perspective shift: Application state is now ${state}`, 'activity');
    };
    document.addEventListener('visibilitychange', handleVisibility);
    return () => document.removeEventListener('visibilitychange', handleVisibility);
  }, [isObserverMode, addLog]);

  useEffect(() => {
    if (!isObserverMode) return;
    const mockActivities = [
      { content: "Scan Complete: Analyzing daily behavioral entropy", category: "activity" },
      { content: "Sync engine: local data buffer optimized", category: "activity" },
      { content: "Detected social input: processing notifications", category: "activity" }
    ];

    const interval = setInterval(() => {
      const randomAction = mockActivities[Math.floor(Math.random() * mockActivities.length)];
      addLog(randomAction.content, randomAction.category as LogCategory);
    }, 45000); 

    return () => clearInterval(interval);
  }, [isObserverMode, addLog]);

  useEffect(() => {
    if (!isObserverMode || logs.length < 5 || logs.length % 5 !== 0) return;
    const triggerProactiveAnalysis = async () => {
      setIsAnalyzing(true);
      try {
        const result = await analyzeLifeLogs(logsRef.current);
        setAnalysis(result);
      } catch (e) {
        console.error("Proactive analysis failed", e);
      } finally {
        setIsAnalyzing(false);
      }
    };
    triggerProactiveAnalysis();
  }, [logs.length, isObserverMode]);

  const toggleObserver = () => {
    setIsObserverMode(!isObserverMode);
    addLog(isObserverMode ? "Observer mode deactivated." : "Autonomous Observer initialized.", "activity");
  };

  const handleRunAnalysis = async () => {
    if (logs.length < 3) return;
    setIsAnalyzing(true);
    try {
      const result = await analyzeLifeLogs(logs);
      setAnalysis(result);
    } catch (error) {
      console.error(error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#030712] text-gray-100 flex flex-col p-4 md:p-8">
      {/* Header */}
      <header className="max-w-7xl mx-auto w-full flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
        <div className="flex items-center gap-4">
          <div>
            <h1 className="text-2xl font-black tracking-tighter flex items-center gap-2">
              <span className="bg-gradient-to-r from-blue-400 via-indigo-500 to-purple-600 bg-clip-text text-transparent">WHATS NEXT</span>
              <div className={`w-1.5 h-1.5 rounded-full ${isObserverMode ? 'bg-red-500 animate-pulse' : 'bg-gray-700'}`}></div>
            </h1>
            <p className="text-gray-600 text-[9px] font-bold uppercase tracking-[0.3em]">Autonomous Observer System</p>
          </div>
          {!isInstalled && (
            <button 
              onClick={handleInstall}
              className="bg-blue-500/10 hover:bg-blue-500/20 border border-blue-500/30 px-3 py-1.5 rounded-lg text-[10px] font-bold text-blue-400 flex items-center gap-2 transition-all"
            >
              <i className="fas fa-download"></i>
              INSTALL
            </button>
          )}
        </div>
        
        <div className="flex gap-2">
          <button 
            onClick={toggleObserver}
            className={`px-5 py-2.5 rounded-2xl font-black text-[10px] flex items-center gap-2 transition-all border ${isObserverMode ? 'bg-red-500/10 border-red-500/30 text-red-500' : 'bg-gray-900 border-white/5 text-gray-400'}`}
          >
            <i className={`fas ${isObserverMode ? 'fa-video' : 'fa-video-slash'}`}></i>
            {isObserverMode ? 'REC ACTIVE' : 'OBSERVER OFF'}
          </button>
          <button 
            onClick={handleRunAnalysis}
            disabled={isAnalyzing || logs.length < 3}
            className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 rounded-2xl font-black text-[10px] transition-all flex items-center gap-2 shadow-xl shadow-blue-900/30"
          >
            {isAnalyzing ? <i className="fas fa-sync fa-spin"></i> : <i className="fas fa-bolt"></i>}
            PREDICT
          </button>
          <div className="w-[1px] h-10 bg-white/5 mx-1"></div>
          <button onClick={shareApp} className="p-2.5 bg-gray-900 hover:bg-gray-800 border border-white/5 rounded-2xl text-blue-400" title="Share App">
             <i className="fas fa-share-alt"></i>
          </button>
          <button onClick={exportData} className="p-2.5 bg-gray-900 hover:bg-gray-800 border border-white/5 rounded-2xl text-gray-500" title="Export Data">
             <i className="fas fa-file-export"></i>
          </button>
        </div>
      </header>

      {/* Main Grid */}
      <main className="max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-6 flex-1">
        <div className="lg:col-span-4 flex flex-col gap-6">
          <div className="glass p-6 rounded-[32px] flex-1 min-h-0 flex flex-col">
             <div className="flex justify-between items-center mb-4">
               <h2 className="text-[11px] font-black text-gray-500 uppercase tracking-widest">Live Activity Buffer</h2>
               <span className="text-[9px] bg-white/5 px-2 py-0.5 rounded text-gray-400">{logs.length} events</span>
             </div>
            <LogList logs={logs} />
          </div>
        </div>

        <div className="lg:col-span-8">
          <div className="glass p-8 rounded-[40px] h-full relative overflow-hidden flex flex-col">
            <div className="absolute top-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-500/5 rounded-full blur-[100px] pointer-events-none"></div>
            
            <div className="relative z-10 flex flex-col h-full">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-8 gap-4 border-b border-white/5 pb-8">
                <div>
                  <h2 className="text-3xl font-black text-white italic tracking-tighter">FUTURE PROJECTION</h2>
                  <p className="text-blue-500/40 text-[10px] font-bold tracking-[0.4em] uppercase mt-1">Stochastic Modeling Hub</p>
                </div>
                <div className="flex gap-4">
                  <div className="text-left md:text-right">
                    <div className="text-[9px] text-gray-600 font-bold uppercase">Simulation Strength</div>
                    <div className="text-lg font-mono text-blue-400">{logs.length > 10 ? 'V-CORE' : 'LITE'}</div>
                  </div>
                </div>
              </div>
              
              <div className="flex-1 overflow-y-auto custom-scrollbar">
                <InsightsPanel analysis={analysis} isLoading={isAnalyzing} />
              </div>

              {!analysis && !isAnalyzing && (
                <div className="flex-1 flex flex-col items-center justify-center text-center">
                   <div className="w-16 h-16 rounded-full border border-blue-500/10 flex items-center justify-center mb-4">
                      <i className="fas fa-brain text-blue-500/20 text-xl animate-pulse"></i>
                   </div>
                   <h3 className="text-base font-bold text-gray-400">Waiting for Data...</h3>
                   <p className="text-gray-600 text-xs mt-2 max-w-[240px]">
                     Start the observer to begin life-cycle analysis.
                   </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      {/* Manual Install Guide Modal */}
      {showInstallGuide && (
        <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center bg-black/80 backdrop-blur-sm p-4" onClick={() => setShowInstallGuide(false)}>
          <div className="glass w-full max-w-md p-8 rounded-[32px] border border-white/10 space-y-6" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center">
              <h3 className="text-xl font-black">How to Install</h3>
              <button onClick={() => setShowInstallGuide(false)} className="text-gray-500 hover:text-white"><i className="fas fa-times"></i></button>
            </div>
            <div className="space-y-4">
              <div className="flex gap-4 items-start">
                <div className="w-8 h-8 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center shrink-0">1</div>
                <p className="text-sm text-gray-300">Open this link in <b>Safari (iOS)</b> or <b>Chrome (Android/PC)</b>.</p>
              </div>
              <div className="flex gap-4 items-start">
                <div className="w-8 h-8 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center shrink-0">2</div>
                <p className="text-sm text-gray-300">Tap the <b>Share</b> icon <i className="fas fa-share-square"></i> (iOS) or the <b>3 dots</b> (Android).</p>
              </div>
              <div className="flex gap-4 items-start">
                <div className="w-8 h-8 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center shrink-0">3</div>
                <p className="text-sm text-gray-300">Select <b>"Add to Home Screen"</b> to turn this into a permanent app.</p>
              </div>
            </div>
            <button 
              onClick={() => setShowInstallGuide(false)}
              className="w-full py-3 bg-blue-600 rounded-2xl font-bold text-sm"
            >
              GOT IT
            </button>
          </div>
        </div>
      )}

      <footer className="max-w-7xl mx-auto w-full mt-6 py-4 flex flex-col md:flex-row justify-between items-center text-[9px] text-gray-600 font-bold uppercase tracking-[0.2em] gap-4">
        <div className="flex gap-6 items-center">
          <span>Observer Integrity: 100%</span>
          <span>Privacy: Local Vault Active</span>
        </div>
        <div className="flex items-center gap-4">
          <span className="opacity-40 italic">Share this link to share the app</span>
          {isInstalled && <span className="text-blue-500 bg-blue-500/10 px-2 py-0.5 rounded border border-blue-500/20">Standalone System</span>}
        </div>
      </footer>
    </div>
  );
};

export default App;
